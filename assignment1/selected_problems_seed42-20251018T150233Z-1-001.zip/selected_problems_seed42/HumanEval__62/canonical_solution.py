    return [(i * x) for i, x in enumerate(xs)][1:]

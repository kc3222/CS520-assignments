    return ''.join(strings)
